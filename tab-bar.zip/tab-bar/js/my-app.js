// Initialize your app
var myApp = new Framework7({domCache: true});

// Export selectors engine
var $$ = Dom7;

// Add views
var view1 = myApp.addView('#view-1', {
    // Because we use fixed-through navbar we can enable dynamic navbar
    dynamicNavbar: true,
    main: true
});
/**/
// Another view
var view2 = myApp.addView('#view-2', {
   dynamicNavbar: true,
    name: 'left'
});
var view3 = myApp.addView('#view-3', {
       dynamicNavbar: true,
       name: 'coupon'
});
var view5 = myApp.addView('#view-5', {
       dynamicNavbar: true,
       name: 'right'
});

// 3 Slides Per View, 10px Between
var mySwiperRestaurants = myApp.swiper('.swiper-restaurants', {
 // pagination:'.swiper-3 .swiper-pagination',
  spaceBetween: 10,
  slidesPerView: 3
});

// 3 Slides Per View, 10px Between
var mySwiperRestaurants = myApp.swiper('.swiper-stores', {
 // pagination:'.swiper-3 .swiper-pagination',
  spaceBetween: 10,
  slidesPerView: 3
});

function restaurantsDeals()
{
  alert(222);
  // console.log(view1);
  // Init main view
  var cards = [
    new Tindercardsjs.card(2, 'Geordi Laforge', 'I like big butts', 'gfx/pics/01.jpg'),
    new Tindercardsjs.card(1, 'Agro Picard', 'Hates Klingons, likes beer.', 'gfx/pics/02.jpg'),
    new Tindercardsjs.card(0, 'Jean-Luc, Worf & William', 'Swipe right if you also like funny hats like us :D', 'gfx/pics/03.jpg')
  ];

  // Render cards
  Tindercardsjs.render(cards, $('#main'), function (event) {
    console.log('Swiped ' + event.direction + ', cardid is ' + event.cardid + ' and target is:');
    console.log(event.card);
  });
  //myApp.views.coupon.router.load({pageName: 'my-page'});
  myApp.views.main.router.loadPage('deals.html');
  //myApp.views.main.router.loadContent(newPageContent);
  //myApp.router.load(view5);
}
function groceryDeals()
{
  // alert(222);
  // console.log(view1);
  // Init main view

  //myApp.views.coupon.router.load({pageName: 'my-page'});
  myApp.views.main.router.loadPage('grocery.html');
  //myApp.views.main.router.loadContent(newPageContent);
  //myApp.router.load(view5);
}


/*

$$("#home-btn").on('click', function (e) {
    alert(111);
});

*/
