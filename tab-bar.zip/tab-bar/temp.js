function stores()
{
	//alert(view5);
	// view5.router.loadPage("about.html");
}

function restaurant()
{
	alert("restaurant");
}